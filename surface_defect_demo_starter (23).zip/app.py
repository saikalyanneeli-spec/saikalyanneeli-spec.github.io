import os
from pathlib import Path

import gradio as gr
from PIL import Image

CHECKPOINT = Path("model.pth")

def analyze_image(image):
    if image is None:
        return None, "Please upload an image first."

    preview = image.convert("RGB")

    if not CHECKPOINT.exists():
        return preview, (
            "Demo interface is working, but no trained model is available yet.\n\n"
            "This project folder does not include the original dataset or a saved "
            "model checkpoint, so it cannot make a genuine defect prediction. "
            "Add a compatible trained model.pth and inference code before using "
            "this as an AI prediction demo."
        )

    # Intentionally do not load an unknown checkpoint or invent a prediction.
    return preview, (
        "A model.pth file was found, but inference has not been connected yet. "
        "Confirm that the checkpoint architecture matches your trained model, "
        "then implement the matching preprocessing and prediction pipeline."
    )

with gr.Blocks(title="Multi-Scale Surface Defect Detection") as demo:
    gr.Markdown(
        "# Multi-Scale Deep Learning Framework for Surface Defect Detection\n"
        "### Manufacturing-line image inspection — project demo\n\n"
        "**Current status:** UI prototype. A trained model and dataset are not included yet."
    )
    with gr.Row():
        image_input = gr.Image(type="pil", label="Upload a product surface image")
        image_preview = gr.Image(type="pil", label="Image preview")
    analyze_btn = gr.Button("Analyze image", variant="primary")
    result = gr.Textbox(label="Analysis status", lines=6)
    analyze_btn.click(analyze_image, inputs=image_input, outputs=[image_preview, result])
    gr.Markdown(
        "---\n"
        "**Important:** This version is a user-interface prototype only. It does not "
        "classify images or claim defect-detection accuracy until a trained model "
        "checkpoint and verified inference pipeline are added."
    )

if __name__ == "__main__":
    demo.launch()
