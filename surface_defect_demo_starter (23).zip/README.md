# Multi-Scale Surface Defect Detection — Demo Starter

This is a deployable **UI prototype** for the academic project:
“Multi-Scale Deep Learning Framework for Surface Defect Detection in Manufacturing Lines.”

## Current limitation

The original dataset and trained `.pth` checkpoint were not provided. Therefore this starter
does **not** make genuine AI predictions. It accepts an image and clearly reports that the
model is not yet connected. Do not describe this version as a working trained defect detector.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open the local URL printed in the terminal.

## Deploy to Hugging Face Spaces

1. Sign in at https://huggingface.co/spaces and create a new Space.
2. Choose **Gradio** as the SDK.
3. Upload `app.py`, `requirements.txt`, and this README.
4. Wait for the Space to build. The Space page will provide its public URL.
5. Describe it honestly as a UI prototype until a real trained model is integrated.

## To turn it into a real AI demo

You will need:
- The training dataset, organized in `dataset/train/<class_name>/...` and
  `dataset/test/<class_name>/...` folders, or a suitable public dataset.
- A corrected, memory-efficient model architecture and training script.
- A saved checkpoint such as `model.pth`.
- Inference preprocessing that exactly matches training preprocessing.
- Evaluation results measured on held-out test data.

The code in the presentation is a useful starting point, but the dataset and checkpoint
are not included. A public link should not claim verified model accuracy until the model
has actually been trained and evaluated.
